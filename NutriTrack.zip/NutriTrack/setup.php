<?php
// setup.php
require 'conexao.php';

try {
    // Apaga a tabela se ela existir (para limpar erros anteriores) e cria de novo
    $pdo->exec("DROP TABLE IF EXISTS usuarios");

    $sql = "CREATE TABLE usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        senha TEXT NOT NULL,
        objetivo TEXT,
        idade INTEGER,
        peso REAL,
        altura REAL,
        sexo TEXT,
        atividade TEXT
    )";

    $pdo->exec($sql);
    echo "Sucesso! A tabela 'usuarios' foi recriada corretamente.";
} catch (PDOException $e) {
    echo "Erro ao criar tabela: " . $e->getMessage();
}
?>
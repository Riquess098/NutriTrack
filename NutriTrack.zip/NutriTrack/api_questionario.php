<?php
// api_questionario.php
require 'conexao.php';
header('Content-Type: application/json');

// Pega os dados enviados pelo JS
$dados = json_decode(file_get_contents("php://input"), true);

if (!$dados || !isset($dados['email'])) {
    echo json_encode(["sucesso" => false, "mensagem" => "Dados inválidos."]);
    exit();
}

try {
    // Atualiza os dados físicos do usuário no banco usando o e-mail como referência
    $stmt = $pdo->prepare("UPDATE usuarios SET objetivo = ?, idade = ?, peso = ?, altura = ?, sexo = ?, atividade = ? WHERE email = ?");
    
    $stmt->execute([
        $dados['objetivo'],
        $dados['idade'],
        $dados['peso'],
        $dados['altura'],
        $dados['sexo'],
        $dados['atividade'],
        $dados['email']
    ]);

    echo json_encode(["sucesso" => true, "mensagem" => "Perfil atualizado com sucesso no banco!"]);

} catch (PDOException $e) {
    echo json_encode(["sucesso" => false, "mensagem" => "Erro ao atualizar: " . $e->getMessage()]);
}
?>
document.addEventListener('DOMContentLoaded', () => {
    const formQuestionario = document.getElementById('form-questionario');
    const modalMeta = document.getElementById('modal-meta');
    const btnSalvarMeta = document.getElementById('btn-salvar-meta');
    const selectDeficit = document.getElementById('escolha-deficit');
    
    let gastoCaloricoTotal = 0;
    let metaFinal = 0;
    let dadosTemporarios = {};

    if (formQuestionario) {
        formQuestionario.addEventListener('submit', (evento) => {
            evento.preventDefault();

            // Pega os dados do usuário atualizados no momento do clique
            const usuarioAtual = JSON.parse(localStorage.getItem('nutritrack_user')) || {};

            dadosTemporarios = {
                objetivo: document.getElementById('objetivo').value,
                idade: parseInt(document.getElementById('idade').value),
                peso: parseFloat(document.getElementById('peso').value),
                altura: parseInt(document.getElementById('altura').value),
                sexo: document.querySelector('input[name="gender"]:checked').value,
                atividade: document.getElementById('atividade').value,
                email: usuarioAtual.email 
            };

            // Cálculo de Harris-Benedict
            let tmb = 0;
            if (dadosTemporarios.sexo === 'male') {
                tmb = 88.362 + (13.397 * dadosTemporarios.peso) + (4.799 * dadosTemporarios.altura) - (5.677 * dadosTemporarios.idade);
            } else {
                tmb = 447.593 + (9.247 * dadosTemporarios.peso) + (3.098 * dadosTemporarios.altura) - (4.330 * dadosTemporarios.idade);
            }

            const niveis = { min: 1.2, low: 1.375, medium: 1.55, high: 1.725, max: 1.9 };
            let fator = niveis[dadosTemporarios.atividade] || 1.2;

            gastoCaloricoTotal = Math.round(tmb * fator);
            metaFinal = gastoCaloricoTotal;

            document.getElementById('valor-basal').textContent = gastoCaloricoTotal;
            document.getElementById('meta-final').textContent = metaFinal;

            modalMeta.style.display = 'flex';
        });
    }

    if (selectDeficit) {
        selectDeficit.addEventListener('change', (e) => {
            metaFinal = gastoCaloricoTotal + parseInt(e.target.value);
            document.getElementById('meta-final').textContent = metaFinal;
        });
    }

    if (btnSalvarMeta) {
        btnSalvarMeta.addEventListener('click', () => {
            const usuarioAtual = JSON.parse(localStorage.getItem('nutritrack_user')) || {};

            // FORÇA a gravação do peso no objeto do usuário
            usuarioAtual.peso = dadosTemporarios.peso;
            usuarioAtual.meta_calorica = metaFinal;

            // Salva no LocalStorage
            localStorage.setItem('nutritrack_user', JSON.stringify(usuarioAtual));
            localStorage.setItem('nutritrack_meta_diaria', metaFinal);

            // Tenta enviar pro banco (não trava a tela se o XAMPP estiver desligado)
            fetch('api_questionario.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dadosTemporarios)
            }).catch(erro => console.error("Erro de conexão com o PHP:", erro));

            // Atraso intencional de 0.5s para o navegador dar conta de salvar tudo
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 500);
        });
    }
});
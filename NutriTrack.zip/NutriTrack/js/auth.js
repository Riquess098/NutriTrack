// VERIFICAÇÃO DE LOGIN
const usuarioLogado = localStorage.getItem('nutritrack_user');


// joga ele direto para o Dashboard (index.html)
if (usuarioLogado) {
    if (window.location.pathname.includes('login.html') || window.location.pathname.includes('cadastro.html')) {
        window.location.href = 'index.html';
    }
}

document.addEventListener('DOMContentLoaded', () => {
  
  //  CADASTRO COM PHP  
  const formCadastro = document.getElementById('form-cadastro');
  
  if (formCadastro) {
    formCadastro.addEventListener('submit', (evento) => {
      evento.preventDefault(); 

      const nome = document.getElementById('nome').value;
      const email = document.getElementById('email').value;
      const senha = document.getElementById('senha').value;
      const confirmaSenha = document.getElementById('confirma-senha').value;

      // Validação do front-end
      if (senha !== confirmaSenha) {
        alert("As senhas não coincidem. Tente novamente!");
        return;
      }

      // Objeto que manda pro servidor
      const usuario = {
        nome: nome,
        email: email,
        senha: senha
      };

      // fetch faz a ponte entre o JS e o PHP
      fetch('api_cadastro.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(usuario)
      })
      .then(resposta => resposta.json())
      .then(dados => {
          if (dados.sucesso) {
              alert(dados.mensagem);
              window.location.href = 'login.html'; // Manda pro login 
          } else {
              alert("Atenção: " + dados.mensagem); // erro email já existe
          }
      })
      .catch(erro => {
          console.error("Erro na comunicação com o servidor:", erro);
          alert("Erro ao conectar com o banco de dados. O XAMPP está rodando?");
      });
    });
  }

  // 2. LÓGICA DE LOGIN (Conectado ao PHP)
  const formLogin = document.getElementById('form-login');

  if (formLogin) {
    formLogin.addEventListener('submit', (evento) => {
      evento.preventDefault();

      const emailDigitado = document.getElementById('email-login').value;
      const senhaDigitada = document.getElementById('senha-login').value;

      const credenciais = {
        email: emailDigitado,
        senha: senhaDigitada
      };

      // Envia os dados para o PHP verificar
      fetch('api_login.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(credenciais)
      })
      .then(resposta => resposta.json())
      .then(dados => {
          if (dados.sucesso) {
              alert(dados.mensagem);
              
              // Salva os dados do usuário (já verificados pelo banco) no navegador
              localStorage.setItem('nutritrack_user', JSON.stringify(dados.usuario));
              
              // Verifica se ele já preencheu o questionário (se tem peso salvo)
              if (dados.usuario.peso) {
                  window.location.href = 'index.html'; // Vai pro Dashboard
              } else {
                  window.location.href = 'questionario.html'; // Vai completar o perfil
              }
          } else {
              alert("Erro: " + dados.mensagem);
          }
      })
      .catch(erro => console.error("Erro no login:", erro));
    });
  }

}); 
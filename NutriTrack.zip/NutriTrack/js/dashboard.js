document.addEventListener('DOMContentLoaded', () => {
    const usuarioLogado = localStorage.getItem('nutritrack_user');

    if (!usuarioLogado) {
        window.location.href = 'login.html';
        return; 
    }

    const usuario = JSON.parse(usuarioLogado);

    if (!usuario.peso && !window.location.pathname.includes('questionario.html')) {
        window.location.href = 'questionario.html';
        return; 
    }

    document.getElementById('nome-usuario').textContent = usuario.nome;

    const metaSalva = localStorage.getItem('nutritrack_meta_diaria');
    if(metaSalva) {
        document.getElementById('meta-calorias').textContent = metaSalva;
        document.getElementById('calorias-restantes').textContent = metaSalva;
    }

    // ==========================================
    // INTEGRAÇÃO API TACO + MODO OFFLINE (FALLBACK)
    // ==========================================
    const inputBusca = document.getElementById('busca-alimento');
    const listaResultadosApi = document.getElementById('lista-resultados-api');
    const listaRefeicoesHoje = document.getElementById('lista-refeicoes');
    
    let alimentosTaco = []; 
    let totalConsumido = 0;

    // BASE DE DADOS RESERVA (Caso o PHP/XAMPP falhe)
    // Escrita no mesmo formato que a API original para o código não quebrar
    const backupTaco = [
        { description: "Arroz branco cozido", attributes: { energy: { kcal: 130 } } },
        { description: "Feijão carioca cozido", attributes: { energy: { kcal: 76 } } },
        { description: "Peito de frango grelhado", attributes: { energy: { kcal: 165 } } },
        { description: "Ovo frito", attributes: { energy: { kcal: 240 } } },
        { description: "Ovo cozido", attributes: { energy: { kcal: 155 } } },
        { description: "Cuscuz de milho", attributes: { energy: { kcal: 112 } } },
        { description: "Tapioca (massa)", attributes: { energy: { kcal: 336 } } },
        { description: "Pão francês", attributes: { energy: { kcal: 300 } } },
        { description: "Carne de sol", attributes: { energy: { kcal: 213 } } },
        { description: "Banana prata", attributes: { energy: { kcal: 98 } } },
        { description: "Maçã", attributes: { energy: { kcal: 52 } } },
        { description: "Queijo mussarela", attributes: { energy: { kcal: 330 } } },
        { description: "Leite integral", attributes: { energy: { kcal: 62 } } },
        { description: "Aveia em flocos", attributes: { energy: { kcal: 394 } } },
        { description: "Batata doce cozida", attributes: { energy: { kcal: 86 } } }
    ];

    // Tenta buscar da API via PHP
    fetch('api_taco.php')
        .then(resposta => {
            if (!resposta.ok) throw new Error("Erro no servidor local");
            return resposta.json();
        })
        .then(dados => {
            if(dados.erro) throw new Error(dados.erro); // Pega o erro que escrevemos no PHP
            
            alimentosTaco = dados;
            if (inputBusca) inputBusca.placeholder = "Pesquisar alimento (API TACO Ativa!)";
        })
        .catch(erro => {
            // SE FALHAR (por falta de SSL no XAMPP ou sem internet), USA O BACKUP!
            console.warn("API falhou, ativando Modo Offline de segurança.", erro);
            alimentosTaco = backupTaco;
            if (inputBusca) inputBusca.placeholder = "Pesquisar alimento (Modo Offline Ativo)";
        });

    if (inputBusca) {
        inputBusca.addEventListener('input', (evento) => {
            const termo = evento.target.value.toLowerCase().trim();
            listaResultadosApi.innerHTML = ''; 
            
            if (termo.length < 2) {
                listaResultadosApi.style.display = 'none';
                return;
            }

            const filtrados = alimentosTaco.filter(alim => 
                alim.description && alim.description.toLowerCase().includes(termo)
            ).slice(0, 10); 

            if (filtrados.length > 0) {
                listaResultadosApi.style.display = 'block';
                
                filtrados.forEach(alim => {
                    const li = document.createElement('li');
                    
                    let kcal = 0;
                    if (alim.attributes && alim.attributes.energy && alim.attributes.energy.kcal) {
                        kcal = Math.round(alim.attributes.energy.kcal);
                    }

                    li.innerHTML = `<strong>${alim.description}</strong> <br><small>${kcal} kcal por 100g</small>`;
                    
                    li.addEventListener('click', () => {
                        adicionarAoPrato(alim.description, kcal);
                        inputBusca.value = '';
                        listaResultadosApi.style.display = 'none';
                    });
                    
                    listaResultadosApi.appendChild(li);
                });
            } else {
                listaResultadosApi.style.display = 'none';
            }
        });
    }

    document.addEventListener('click', (e) => {
        if (inputBusca && !inputBusca.contains(e.target) && !listaResultadosApi.contains(e.target)) {
            listaResultadosApi.style.display = 'none';
        }
    });

    function adicionarAoPrato(nome, calorias) {
        const itemLista = document.createElement('li');
        itemLista.style.cssText = "padding: 12px; border-bottom: 1px solid var(--color-gray-lighter); display: flex; justify-content: space-between; font-size: 16px; color: var(--color-gray-dark);";
        itemLista.innerHTML = `<span>${nome} (100g)</span> <span style="color: var(--color-warning); font-weight: bold;">+${calorias} kcal</span>`;
        listaRefeicoesHoje.appendChild(itemLista);

        totalConsumido += calorias;
        document.getElementById('calorias-consumidas').textContent = totalConsumido;

        const meta = parseInt(document.getElementById('meta-calorias').textContent) || 0;
        let restante = meta - totalConsumido;
        
        const elementoRestante = document.getElementById('calorias-restantes');
        elementoRestante.textContent = restante;

        if (restante < 0) {
            elementoRestante.style.color = "red";
        } else {
            elementoRestante.style.color = "#28a745";
        }
    }

    const btnSair = document.getElementById('btn-sair');
    if (btnSair) {
        btnSair.addEventListener('click', () => {
            localStorage.removeItem('nutritrack_user');
            localStorage.removeItem('nutritrack_meta_diaria');
            window.location.href = 'login.html';
        });
    }
});
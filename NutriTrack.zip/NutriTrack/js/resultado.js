export default class Resultado {
  constructor(element) {
    this.root = element.querySelector('.counter__result');
    this.campoNorm = this.root.querySelector('#calories-norm');
    this.campoMin = this.root.querySelector('#calories-minimal');
    this.campoMax = this.root.querySelector('#calories-maximal');
  }

  mostrar(calorias) {
    this.campoNorm.textContent = calorias.norm.toLocaleString('pt-BR');
    this.campoMin.textContent = calorias.minimal.toLocaleString('pt-BR');
    this.campoMax.textContent = calorias.maximal.toLocaleString('pt-BR');

    this.root.classList.remove('counter__result--hidden');
  }

  esconder() {
    this.root.classList.add('counter__result--hidden');
  }
}
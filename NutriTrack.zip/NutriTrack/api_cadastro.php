<?php
// api_cadastro.php
require 'conexao.php';

header('Content-Type: application/json');

$dados = json_decode(file_get_contents("php://input"), true);

if (!$dados) {
    echo json_encode(["sucesso" => false, "mensagem" => "Nenhum dado recebido."]);
    exit();
}

$nome = $dados['nome'];
$email = $dados['email'];
$senha_criptografada = password_hash($dados['senha'], PASSWORD_DEFAULT); 

try {
    $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
    $stmt->execute([$nome, $email, $senha_criptografada]);
    
    echo json_encode(["sucesso" => true, "mensagem" => "Cadastro realizado com sucesso!"]);

} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
         echo json_encode(["sucesso" => false, "mensagem" => "Este e-mail já está cadastrado."]);
    } else {
         // Esta linha vai nos contar o segredo do erro
         echo json_encode(["sucesso" => false, "mensagem" => "Erro técnico: " . $e->getMessage()]);
    }
}
?>
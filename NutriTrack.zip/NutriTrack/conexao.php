<?php
// conexao.php
try {
    // Vamos padronizar o nome do arquivo do banco como nutritrack.sqlite
    $pdo = new PDO('sqlite:nutritrack.sqlite'); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
    exit();
}
?>
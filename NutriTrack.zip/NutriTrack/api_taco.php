<?php
// api_taco.php

// Avisa ao navegador que a resposta será no formato JSON
header('Content-Type: application/json');

// Permite que o seu JavaScript local consiga ler este arquivo sem bloqueio de CORS
header('Access-Control-Allow-Origin: *');

// O endereço da API oficial da TACO na internet
$url = 'https://taco-api-nodejs.vercel.app/api/v1/food';

// O PHP vai até a internet e baixa a lista inteira de alimentos
// Usamos o '@' para ocultar mensagens de erro feias do PHP caso a internet caia
$dados_taco = @file_get_contents($url);

if ($dados_taco === false) {
    // Se o PHP não conseguir conectar na internet, ele avisa o erro
    http_response_code(500);
    echo json_encode(["erro" => "Falha ao conectar com a API externa da TACO. Verifique sua internet."]);
} else {
    // Se der certo, ele imprime (devolve) todos os dados diretamente para o seu JavaScript!
    echo $dados_taco;
}
?>
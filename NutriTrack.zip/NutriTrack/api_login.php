<?php
// api_login.php
require 'conexao.php';

// Avisa o navegador que vamos responder no formato JSON
header('Content-Type: application/json');

// Pega os dados que o JavaScript enviou
$dados = json_decode(file_get_contents("php://input"), true);

if (!$dados) {
    echo json_encode(["sucesso" => false, "mensagem" => "Dados não recebidos."]);
    exit();
}

$email = $dados['email'];
$senha = $dados['senha'];

try {
    // Busca no banco se existe alguém com esse e-mail
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verifica se achou o usuário e se a senha bate com a senha criptografada do banco
    if ($usuario && password_verify($senha, $usuario['senha'])) {
        
        // Remove a senha da resposta antes de mandar de volta pro JavaScript (segurança básica)
        unset($usuario['senha']);
        
        echo json_encode(["sucesso" => true, "mensagem" => "Login aprovado!", "usuario" => $usuario]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "E-mail ou senha incorretos."]);
    }

} catch (PDOException $e) {
    echo json_encode(["sucesso" => false, "mensagem" => "Erro no banco: " . $e->getMessage()]);
}
?>